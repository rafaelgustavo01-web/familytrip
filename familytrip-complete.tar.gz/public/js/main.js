// Family Trip App
console.log("App loaded");
